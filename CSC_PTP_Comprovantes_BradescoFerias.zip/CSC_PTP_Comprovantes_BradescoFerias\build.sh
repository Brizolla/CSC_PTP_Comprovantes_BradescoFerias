#!/bin/bash

zip -r "CSC_PTP_Comprovantes_BradescoFerias.zip" * -x "CSC_PTP_Comprovantes_BradescoFerias.zip"